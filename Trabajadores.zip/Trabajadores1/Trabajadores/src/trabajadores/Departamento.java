
package trabajadores;



public class Departamento {
    private String nombreDepartamento;
    private String nombreTrabajador;

    public Departamento(String nombreDepartamento, String nombreTrabajador) {
        this.nombreDepartamento = nombreDepartamento;
        this.nombreTrabajador = nombreTrabajador;
    }

    public String getNombreDepartamento() {
        return nombreDepartamento;
    }

    public void setNombreDepartamento(String nombreDepartamento) {
        this.nombreDepartamento = nombreDepartamento;
    }

    public String getNombreTrabajador() {
        return nombreTrabajador;
    }

    public void setNombreTrabajador(String nombreTrabajador) {
        this.nombreTrabajador = nombreTrabajador;
    }
}
