/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package trabajadores;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author lolda
 */
public class Interfaz extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public Interfaz() {
        super("Registro de Trabajador");
        initComponents();
        
       
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        Dni = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        Telefono = new javax.swing.JLabel();
        Puesto = new javax.swing.JLabel();
        Departamento = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cmbDepartamento = new javax.swing.JComboBox<>();
        cmbTipoContrato = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnCargar = new javax.swing.JButton();
        btnCalcularSueldo = new javax.swing.JButton();
        CambiarNombre = new javax.swing.JButton();
        CambiarTelefono = new javax.swing.JButton();
        CambiarDepartamento = new javax.swing.JButton();
        CambiarTipoContrato = new javax.swing.JButton();
        CambiarDiasTrabajados = new javax.swing.JButton();
        btnDespedir = new javax.swing.JButton();
        CambiarPuesto = new javax.swing.JButton();
        cmbPuesto = new javax.swing.JComboBox<>();
        txtNombre = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtDiasTrabajados = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(51, 153, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel1.setText("Lista de los Trabajadores");

        jComboBox1.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "<Seleccione>" }));
        jComboBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox1MouseClicked(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        Dni.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        Dni.setText("DNI");

        Nombre.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        Nombre.setText("Nombre");

        Telefono.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        Telefono.setText("Teléfono");

        Puesto.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        Puesto.setText("Puesto");

        Departamento.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        Departamento.setText("Departamento");

        jLabel7.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel7.setText("Tipo de Contrato");

        jLabel8.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel8.setText("Dias trabajados");

        cmbDepartamento.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        cmbDepartamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seguridad", "Servicios de plataforma inteligentes", "Servicios de ingenieria de software", "Datos e inteligencia artificial" }));

        cmbTipoContrato.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        cmbTipoContrato.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Indefinido", "Definido" }));
        cmbTipoContrato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTipoContratoActionPerformed(evt);
            }
        });

        btnGuardar.setBackground(new java.awt.Color(255, 51, 51));
        btnGuardar.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCargar.setBackground(new java.awt.Color(255, 51, 51));
        btnCargar.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        btnCargar.setText("Cargar");
        btnCargar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarActionPerformed(evt);
            }
        });

        btnCalcularSueldo.setBackground(new java.awt.Color(255, 0, 0));
        btnCalcularSueldo.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        btnCalcularSueldo.setText("Calcular Sueldo");
        btnCalcularSueldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularSueldoActionPerformed(evt);
            }
        });

        CambiarNombre.setBackground(new java.awt.Color(102, 204, 255));
        CambiarNombre.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        CambiarNombre.setText("Cambiar");
        CambiarNombre.setActionCommand("Cambiar1");
        CambiarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CambiarNombreActionPerformed(evt);
            }
        });

        CambiarTelefono.setBackground(new java.awt.Color(102, 204, 255));
        CambiarTelefono.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        CambiarTelefono.setText("Cambiar");
        CambiarTelefono.setActionCommand("Cambiar2");
        CambiarTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CambiarTelefonoActionPerformed(evt);
            }
        });

        CambiarDepartamento.setBackground(new java.awt.Color(102, 204, 255));
        CambiarDepartamento.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        CambiarDepartamento.setText("Cambiar");
        CambiarDepartamento.setActionCommand("Cambiar3");
        CambiarDepartamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CambiarDepartamentoActionPerformed(evt);
            }
        });

        CambiarTipoContrato.setBackground(new java.awt.Color(102, 204, 255));
        CambiarTipoContrato.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        CambiarTipoContrato.setText("Cambiar");
        CambiarTipoContrato.setActionCommand("Cambiar4");
        CambiarTipoContrato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CambiarTipoContratoActionPerformed(evt);
            }
        });

        CambiarDiasTrabajados.setBackground(new java.awt.Color(102, 204, 255));
        CambiarDiasTrabajados.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        CambiarDiasTrabajados.setText("Cambiar");
        CambiarDiasTrabajados.setActionCommand("Cambiar5");
        CambiarDiasTrabajados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CambiarDiasTrabajadosActionPerformed(evt);
            }
        });

        btnDespedir.setBackground(new java.awt.Color(255, 51, 51));
        btnDespedir.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        btnDespedir.setText("Despedir");
        btnDespedir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDespedirActionPerformed(evt);
            }
        });

        CambiarPuesto.setBackground(new java.awt.Color(102, 204, 255));
        CambiarPuesto.setFont(new java.awt.Font("Lucida Console", 0, 12)); // NOI18N
        CambiarPuesto.setText("Cambiar");
        CambiarPuesto.setActionCommand("Cambiar6");
        CambiarPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CambiarPuestoActionPerformed(evt);
            }
        });

        cmbPuesto.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N
        cmbPuesto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Operario", "Supervisor", "Gerente", "Director de departamento", "Vicepresidente", "Director ejecutivo" }));

        txtNombre.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N

        txtDni.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N

        txtTelefono.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N

        txtDiasTrabajados.setFont(new java.awt.Font("Bahnschrift", 2, 12)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Dni, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Nombre)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(Puesto, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Telefono, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(cmbPuesto, 0, 379, Short.MAX_VALUE)
                                    .addComponent(txtDni, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtTelefono))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CambiarTelefono)
                                    .addComponent(CambiarNombre)
                                    .addComponent(CambiarPuesto)
                                    .addComponent(CambiarDepartamento)
                                    .addComponent(CambiarTipoContrato)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnGuardar)
                                        .addGap(12, 12, 12)
                                        .addComponent(btnDespedir)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnCalcularSueldo))))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDiasTrabajados, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(CambiarDiasTrabajados))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Departamento)
                            .addComponent(jLabel7))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cmbDepartamento, 0, 301, Short.MAX_VALUE)
                            .addComponent(cmbTipoContrato, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 597, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(btnCargar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(75, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(btnCargar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Dni)
                    .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Nombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CambiarNombre))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CambiarTelefono)
                    .addComponent(Telefono)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Puesto)
                    .addComponent(CambiarPuesto)
                    .addComponent(cmbPuesto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Departamento)
                    .addComponent(cmbDepartamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CambiarDepartamento))
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cmbTipoContrato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CambiarTipoContrato))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8)
                        .addComponent(txtDiasTrabajados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(CambiarDiasTrabajados))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnCalcularSueldo)
                    .addComponent(btnDespedir))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        dispose();
        String dni1 = jComboBox1.getSelectedItem().toString();
        StringTokenizer st= new StringTokenizer(dni1,",");
        String dni2 = st.nextToken();
            String dni = txtDni.getText();
            String nombre = txtNombre.getText();
            String telefono = txtTelefono.getText();
            String puesto = cmbPuesto.getSelectedItem().toString();
            String departamento = cmbDepartamento.getSelectedItem().toString();
            String tipoContrato = cmbTipoContrato.getSelectedItem().toString();
            int diasTrabajados;

            if (tipoContrato.equals("Indefinido")) {
                diasTrabajados = 30;
            } else {
                String diasTrabajadosText = txtDiasTrabajados.getText();
                diasTrabajados = Integer.parseInt(diasTrabajadosText);
            }
            boolean dias_trabajados = false;
            if (diasTrabajados<0){
                dias_trabajados=true;
             }
            boolean dniRepetido = false;
            boolean telefonoRepetido = false;

            try (BufferedReader reader = new BufferedReader(new FileReader("datos_trabajador.txt"))) {
                String line;
            while ((line = reader.readLine()) != null) {
        String[] parts = line.split(",");
        if (parts.length >= 1 && parts[0].startsWith("DNI:") && parts[0].contains(dni)) {
                        dniRepetido = true;
                        break;
                    }
                    if (parts.length >= 1 && parts[0].startsWith("DNI:") && parts[2].contains(telefono)) {
                        telefonoRepetido = true;
                        break;
                    }
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            
            
            

            if (dniRepetido) {
                JOptionPane.showMessageDialog(this, "El DNI " + dni + " está repetido. No se guardarán los datos del trabajador.");
            } else if (telefonoRepetido) {
                JOptionPane.showMessageDialog(this, "El teléfono " + telefono + " está repetido. No se guardarán los datos del trabajador.");
            } else if(dni.isEmpty()){
                JOptionPane.showMessageDialog(this, "El DNI esta vacio, no se puede guardar al trabajador. ");
            }else if(dias_trabajados){
                JOptionPane.showMessageDialog(this, "Los dias no pueden ser negativos. No se guardaran los datos. ");
            }else{

            Trabajador trabajador = new Trabajador(dni, nombre, telefono, puesto, tipoContrato,departamento);
            trabajador.setDiasTrabajados(diasTrabajados);

            GuardarDatosTrabajador.guardarDatos(trabajador);
            JOptionPane.showMessageDialog(this, "Los datos del trabajador se han guardado correctamente.");}
            
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarActionPerformed
        String dni1 = jComboBox1.getSelectedItem().toString();
        StringTokenizer st= new StringTokenizer(dni1,",");
        String dni2 = st.nextToken();
                
                
            
        
            
        Trabajador trabajador = null;
        
        
        boolean trabajador_encontrado=false;
        try (BufferedReader reader = new BufferedReader(new FileReader("lista_trabajadores.txt"))){
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("DNI:") && line.substring(0).equals(dni1)){
                    trabajador_encontrado=true;
                }}
        
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(trabajador_encontrado){
        try (BufferedReader reader = new BufferedReader(new FileReader("datos_trabajador.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
        String[] parts = line.split(",");
        if (parts.length >= 1 && parts[0].startsWith("DNI:") && parts[0].contains(dni2)) {
            String dni = parts[0].substring(5).trim();
            String nombre = parts[1].substring(8).trim();
            String telefono = parts[2].substring(10).trim();
            String puesto = parts[3].substring(8).trim();
            String departamento = parts[4].substring(14).trim();
            String tipoContrato = parts[5].substring(18).trim();
            int diasTrabajados = Integer.parseInt(parts[6].substring(17).trim());
            
            trabajador = new Trabajador(dni, nombre, telefono, puesto, tipoContrato, departamento);
            trabajador.setDiasTrabajados(diasTrabajados);
            break;
        }
    }
        } catch (IOException e) {
            e.printStackTrace();
        }
        }
        
        
            Trabajador trabajadorCargado = null;
            trabajadorCargado = trabajador;
            if (trabajadorCargado != null) {
                txtDni.setText(trabajadorCargado.getDni());
                txtNombre.setText(trabajadorCargado.getNombre());
                txtTelefono.setText(trabajadorCargado.getTelefono());
                cmbPuesto.setSelectedItem(trabajadorCargado.getPuesto());
                cmbDepartamento.setSelectedItem(trabajadorCargado.getDepartamento());
                cmbTipoContrato.setSelectedItem(trabajadorCargado.getTipoContrato());
                txtDiasTrabajados.setText(String.valueOf(trabajadorCargado.getDiasTrabajados()));
                JOptionPane.showMessageDialog(this, "Los datos del trabajador se han cargado correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudieron cargar los datos del trabajador.");
            }
    }//GEN-LAST:event_btnCargarActionPerformed

    private void btnDespedirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDespedirActionPerformed
        dispose();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DespedirTrabajador().setVisible(true);
            }
        });
        ;
    }//GEN-LAST:event_btnDespedirActionPerformed

    private void btnCalcularSueldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularSueldoActionPerformed
        String dni1 = jComboBox1.getSelectedItem().toString();
        
        if(dni1.equals("<Seleccione>")){
            JOptionPane.showMessageDialog(this, "No ha seleccionado a ningun trabajador. Seleccione al trabajador para poder calcular su sueldo");
            
        }else{
        
        
        
        StringTokenizer st= new StringTokenizer(dni1,",");
        String dni2 = st.nextToken();
        double sueldo = 0.0;
                
            
        
            
        Trabajador trabajador = null;
        
        
        boolean trabajador_encontrado=false;
        try (BufferedReader reader = new BufferedReader(new FileReader("lista_trabajadores.txt"))){
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("DNI:") && line.substring(0).equals(dni1)){
                    trabajador_encontrado=true;
                }}
        
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(trabajador_encontrado){
        try (BufferedReader reader = new BufferedReader(new FileReader("datos_trabajador.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
        String[] parts = line.split(",");
        if (parts.length >= 1 && parts[0].startsWith("DNI:") && parts[0].contains(dni2)) {
            String dni = parts[0].substring(5).trim();
            String nombre = parts[1].substring(8).trim();
            String telefono = parts[2].substring(10).trim();
            String puesto = parts[3].substring(8).trim();
            String departamento = parts[4].substring(14).trim();
            String tipoContrato = parts[5].substring(18).trim();
            int diasTrabajados = Integer.parseInt(parts[6].substring(17).trim());
            
            trabajador = new Trabajador(dni, nombre, telefono, puesto, tipoContrato, departamento);
            trabajador.setDiasTrabajados(diasTrabajados);
            
            if(trabajador.getPuesto().equals("Operario")){
                        sueldo=diasTrabajados*35;
                    }else if(trabajador.getPuesto().equals("Supervisor")){
                        sueldo=diasTrabajados*45;
                    }else if(trabajador.getPuesto().equals("Gerente")){
                        sueldo=diasTrabajados*55;
                    }else if(trabajador.getPuesto().equals("Director de departamento")){
                        sueldo=diasTrabajados*65;
                    }else if(trabajador.getPuesto().equals("Vicepresidente")){
                        sueldo=diasTrabajados*75;
                    }else if(trabajador.getPuesto().equals("Director ejecutivo")){
                        sueldo=diasTrabajados*85;
                    }
            
        }
    }
        } catch (IOException e) {
            e.printStackTrace();
        }
        JOptionPane.showMessageDialog(this, "El saldo del trabajador es de: " + sueldo +"€");
        }
        }
        
        
    }//GEN-LAST:event_btnCalcularSueldoActionPerformed

    private void CambiarTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CambiarTelefonoActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarTelefono().setVisible(true);
            }
        });
            
    }//GEN-LAST:event_CambiarTelefonoActionPerformed

    private void CambiarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CambiarNombreActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarNombre().setVisible(true);
            }
        });
        dispose();
            
            
    }//GEN-LAST:event_CambiarNombreActionPerformed

    private void CambiarPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CambiarPuestoActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarPuesto().setVisible(true);
            }
        });
            
    }//GEN-LAST:event_CambiarPuestoActionPerformed

    private void CambiarTipoContratoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CambiarTipoContratoActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarContrato().setVisible(true);
            }
        });
            
    }//GEN-LAST:event_CambiarTipoContratoActionPerformed

    private void CambiarDiasTrabajadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CambiarDiasTrabajadosActionPerformed
        String dni1 = jComboBox1.getSelectedItem().toString();
            StringTokenizer st= new StringTokenizer(dni1,",");
            String dni2 = st.nextToken();
        
        String contrato = cmbTipoContrato.getSelectedItem().toString();  
         
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarDias().setVisible(true);
            }
        });
            
        
    }//GEN-LAST:event_CambiarDiasTrabajadosActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MouseClicked
        jComboBox1.removeAllItems();
        FileReader fileReader=null;
        try {
            String cadenaleida="";
            fileReader = new FileReader("lista_trabajadores.txt");
            BufferedReader bufferedReader =new BufferedReader(fileReader);
            cadenaleida=bufferedReader.readLine();
            while(cadenaleida!=null){
                StringTokenizer st= new StringTokenizer(cadenaleida,"\n");
                String lista = st.nextToken();
                jComboBox1.addItem(lista);
                cadenaleida=bufferedReader.readLine();
            }
            bufferedReader.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fileReader.close();
            } catch (IOException ex) {
                Logger.getLogger(Interfaz.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jComboBox1MouseClicked

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated

    }//GEN-LAST:event_formWindowActivated

    private void cmbTipoContratoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoContratoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbTipoContratoActionPerformed

    private void CambiarDepartamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CambiarDepartamentoActionPerformed
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CambiarDepartamento().setVisible(true);
            }
        });
    }//GEN-LAST:event_CambiarDepartamentoActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CambiarDepartamento;
    private javax.swing.JButton CambiarDiasTrabajados;
    private javax.swing.JButton CambiarNombre;
    private javax.swing.JButton CambiarPuesto;
    private javax.swing.JButton CambiarTelefono;
    private javax.swing.JButton CambiarTipoContrato;
    private javax.swing.JLabel Departamento;
    private javax.swing.JLabel Dni;
    private javax.swing.JLabel Nombre;
    private javax.swing.JLabel Puesto;
    private javax.swing.JLabel Telefono;
    private javax.swing.JButton btnCalcularSueldo;
    private javax.swing.JButton btnCargar;
    private javax.swing.JButton btnDespedir;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> cmbDepartamento;
    private javax.swing.JComboBox<String> cmbPuesto;
    private javax.swing.JComboBox<String> cmbTipoContrato;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField txtDiasTrabajados;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
