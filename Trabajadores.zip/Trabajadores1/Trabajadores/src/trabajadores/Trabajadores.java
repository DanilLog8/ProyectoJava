
package trabajadores;

import javax.swing.SwingUtilities;


public class Trabajadores {

    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    
}
